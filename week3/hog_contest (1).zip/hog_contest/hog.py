"""This is a minimal contest submission file. You may also submit the full
hog.py from Project 1 as your contest entry."""

GOAL_SCORE = 100

def final_strategy(score, opponent_score):
    return 5

final_bid = 0
